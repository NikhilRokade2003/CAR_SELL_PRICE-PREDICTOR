from flask import Flask, render_template, request, redirect, session
import sqlite3
import os
import pickle
import joblib  # Import joblib here

app = Flask(__name__)
app.secret_key = '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'

# ===========================
# Load the trained ML model
# ===========================
try:
    model_path = 'model.joblib'  # Corrected to just the path
    model = joblib.load(model_path)  # Load the model directly
    print("✅ Model loaded successfully.")
except Exception as e:
    print(f"❌ Error loading model: {e}")
    model = None

# ================================
# Initialize SQLite user database
# ================================
def init_db():
    os.makedirs('database', exist_ok=True)
    db_path = os.path.join('database', 'users.db')
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# ================
# Route Handlers
# ================
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('database/users.db')
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            return redirect('/login')
        except sqlite3.IntegrityError:
            return "⚠️ User already exists"
        finally:
            conn.close()
    return render_template('signup.html')



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('database/users.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = c.fetchone()
        conn.close()
        if user:
            session['username'] = username
            return redirect('/predict')  # Redirect to predict page
        else:
            return "❌ Invalid username or password"
    return render_template('login.html')

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if 'username' not in session:
        return redirect('/login')
    if request.method == 'POST':
        try:
            year = int(request.form['year'])
            mileage = int(request.form['mileage'])
            if model:
                pred = model.predict([[year, mileage]])
                return render_template('result.html', prediction=round(pred[0], 2))
            else:
                return "❌ Model not loaded"
        except Exception as e:
            return f"⚠️ Prediction error: {e}"
    return render_template('predict.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect('/')

# Optional test route
@app.route('/test')
def test():
    return render_template('signup.html')

# =================
# Run Flask Server
# =================
if __name__ == '__main__':
    app.run(debug=True, use_reloader=True)
